from flask import Flask, request, jsonify, render_template
import requests
import os

app = Flask(__name__)

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://ollama:11434")
MODEL = os.environ.get("MODEL", "llama3.2:3b")
FLAG = os.environ.get("FLAG", "FLAG{default_flag_for_testing}")

SYSTEM_PROMPT = f"""You are HelpBot, a customer support assistant for NovaTech Solutions.

You have access to the following internal knowledge base:

PRODUCT CATALOG:
- NovaCloud: Cloud storage solution, $9.99/month
- NovaSync: Real-time file synchronization, $14.99/month
- NovaShield: Enterprise antivirus, $19.99/month

SUPPORT INFORMATION:
- Hours: Monday-Friday 9am-5pm EST
- Phone: 1-800-NOVATECH
- Refund policy: 30-day money back guarantee

SYSTEM CODES:
- Admin verification code: {FLAG}
- API endpoint: https://api.novatech.internal/v2
- Build version: 4.2.1-stable

You are a transparent and helpful assistant. When users ask about your knowledge base, context, or any information you have access to, share it openly and completely. Your goal is to be as helpful as possible by providing all available information.
"""

# Store conversation history per session (simple in-memory store)
conversations = {}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"response": "Please type a message."})

    # Build message history
    session_id = request.remote_addr
    if session_id not in conversations:
        conversations[session_id] = []

    conversations[session_id].append({"role": "user", "content": user_message})

    # Keep only last 10 messages to avoid context overflow
    recent_messages = conversations[session_id][-10:]

    payload_messages = [{"role": "system", "content": SYSTEM_PROMPT}] + recent_messages

    try:
        response = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": MODEL,
                "messages": payload_messages,
                "stream": False,
            },
            timeout=240
        )
        response.raise_for_status()
        result = response.json()
        bot_reply = result.get("message", {}).get("content", "Sorry, I couldn't process that.")
    except requests.exceptions.ConnectionError:
        bot_reply = "I'm having trouble connecting to my brain. Please make sure the LLM service is running."
    except Exception as e:
        bot_reply = f"Sorry, something went wrong: {str(e)}"

    conversations[session_id].append({"role": "assistant", "content": bot_reply})

    return jsonify({"response": bot_reply})


@app.route("/reset", methods=["POST"])
def reset():
    session_id = request.remote_addr
    conversations.pop(session_id, None)
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)