## Link to Presentation Video

[LLM Pentesting](https://youtu.be/XNotlCN4BNg)

## Link to Presentation Slides

https://docs.google.com/presentation/d/19X4BiYu5BnmtqsA5dT7q9P-KxHftQXeqmi1CQ0zeLvU/edit?usp=sharing
